import{s as B,q as O,r as p,H as U,ag as M,ah as G,O as P,j as y,x as j,c as h,z as T,E as H,G as L,J as V,ai as R,aj as I,ak as N,al as A}from"./index-SfJRQYy3.js";import{d as S}from"./Stack-Cp3aa7K2.js";function X(t){return String(t).match(/[\d.\-+]*\s*(.*)/)[1]||""}function z(t){return parseFloat(t)}function D(t){return O("MuiMenuItem",t)}const c=B("MuiMenuItem",["root","focusVisible","dense","disabled","divider","gutters","selected"]),W=(t,e)=>{const{ownerState:a}=t;return[e.root,a.dense&&e.dense,a.divider&&e.divider,!a.disableGutters&&e.gutters]},K=t=>{const{disabled:e,dense:a,divider:s,disableGutters:o,selected:i,classes:n}=t,r=T({root:["root",a&&"dense",e&&"disabled",!o&&"gutters",s&&"divider",i&&"selected"]},D,n);return{...n,...r}},q=j(H,{shouldForwardProp:t=>L(t)||t==="classes",name:"MuiMenuItem",slot:"Root",overridesResolver:W})(V(({theme:t})=>({...t.typography.body1,display:"flex",justifyContent:"flex-start",alignItems:"center",position:"relative",textDecoration:"none",minHeight:48,paddingTop:6,paddingBottom:6,boxSizing:"border-box",whiteSpace:"nowrap","&:hover":{textDecoration:"none",backgroundColor:(t.vars||t).palette.action.hover,"@media (hover: none)":{backgroundColor:"transparent"}},[`&.${c.selected}`]:{backgroundColor:t.alpha((t.vars||t).palette.primary.main,(t.vars||t).palette.action.selectedOpacity),[`&.${c.focusVisible}`]:{backgroundColor:t.alpha((t.vars||t).palette.primary.main,`${(t.vars||t).palette.action.selectedOpacity} + ${(t.vars||t).palette.action.focusOpacity}`)}},[`&.${c.selected}:hover`]:{backgroundColor:t.alpha((t.vars||t).palette.primary.main,`${(t.vars||t).palette.action.selectedOpacity} + ${(t.vars||t).palette.action.hoverOpacity}`),"@media (hover: none)":{backgroundColor:t.alpha((t.vars||t).palette.primary.main,(t.vars||t).palette.action.selectedOpacity)}},[`&.${c.focusVisible}`]:{backgroundColor:(t.vars||t).palette.action.focus},[`&.${c.disabled}`]:{opacity:(t.vars||t).palette.action.disabledOpacity},[`& + .${S.root}`]:{marginTop:t.spacing(1),marginBottom:t.spacing(1)},[`& + .${S.inset}`]:{marginLeft:52},[`& .${I.root}`]:{marginTop:0,marginBottom:0},[`& .${I.inset}`]:{paddingLeft:36},[`& .${R.root}`]:{minWidth:36},variants:[{props:({ownerState:e})=>!e.disableGutters,style:{paddingLeft:16,paddingRight:16}},{props:({ownerState:e})=>e.divider,style:{borderBottom:`1px solid ${(t.vars||t).palette.divider}`,backgroundClip:"padding-box"}},{props:({ownerState:e})=>!e.dense,style:{[t.breakpoints.up("sm")]:{minHeight:"auto"}}},{props:({ownerState:e})=>e.dense,style:{minHeight:32,paddingTop:4,paddingBottom:4,...t.typography.body2,[`& .${R.root} svg`]:{fontSize:"1.25rem"}}}]}))),at=p.forwardRef(function(e,a){const s=U({props:e,name:"MuiMenuItem"}),{autoFocus:o=!1,component:i="li",dense:n=!1,divider:l=!1,disableGutters:r=!1,focusVisibleClassName:f,role:g="menuitem",tabIndex:d,className:u,...v}=s,k=p.useContext(M),$=p.useMemo(()=>({dense:n||k.dense||!1,disableGutters:r}),[k.dense,n,r]),b=p.useRef(null);G(()=>{o&&b.current&&b.current.focus()},[o]);const E={...s,dense:$.dense,divider:l,disableGutters:r},m=K(s),F=P(b,a);let w;return s.disabled||(w=d!==void 0?d:-1),y.jsx(M.Provider,{value:$,children:y.jsx(q,{ref:F,role:g,tabIndex:w,component:i,focusVisibleClassName:h(m.focusVisible,f),className:h(m.root,u),...v,ownerState:E,classes:m})})});function J(t){return O("MuiSkeleton",t)}B("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);const Q=t=>{const{classes:e,variant:a,animation:s,hasChildren:o,width:i,height:n}=t;return T({root:["root",a,s,o&&"withChildren",o&&!i&&"fitContent",o&&!n&&"heightAuto"]},J,e)},C=A`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`,x=A`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`,Y=typeof C!="string"?N`
        animation: ${C} 2s ease-in-out 0.5s infinite;
      `:null,Z=typeof x!="string"?N`
        &::after {
          animation: ${x} 2s linear 0.5s infinite;
        }
      `:null,_=j("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(t,e)=>{const{ownerState:a}=t;return[e.root,e[a.variant],a.animation!==!1&&e[a.animation],a.hasChildren&&e.withChildren,a.hasChildren&&!a.width&&e.fitContent,a.hasChildren&&!a.height&&e.heightAuto]}})(V(({theme:t})=>{const e=X(t.shape.borderRadius)||"px",a=z(t.shape.borderRadius);return{display:"block",backgroundColor:t.vars?t.vars.palette.Skeleton.bg:t.alpha(t.palette.text.primary,t.palette.mode==="light"?.11:.13),height:"1.2em",variants:[{props:{variant:"text"},style:{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${a}${e}/${Math.round(a/.6*10)/10}${e}`,"&:empty:before":{content:'"\\00a0"'}}},{props:{variant:"circular"},style:{borderRadius:"50%"}},{props:{variant:"rounded"},style:{borderRadius:(t.vars||t).shape.borderRadius}},{props:({ownerState:s})=>s.hasChildren,style:{"& > *":{visibility:"hidden"}}},{props:({ownerState:s})=>s.hasChildren&&!s.width,style:{maxWidth:"fit-content"}},{props:({ownerState:s})=>s.hasChildren&&!s.height,style:{height:"auto"}},{props:{animation:"pulse"},style:Y||{animation:`${C} 2s ease-in-out 0.5s infinite`}},{props:{animation:"wave"},style:{position:"relative",overflow:"hidden",WebkitMaskImage:"-webkit-radial-gradient(white, black)","&::after":{background:`linear-gradient(
                90deg,
                transparent,
                ${(t.vars||t).palette.action.hover},
                transparent
              )`,content:'""',position:"absolute",transform:"translateX(-100%)",bottom:0,left:0,right:0,top:0}}},{props:{animation:"wave"},style:Z||{"&::after":{animation:`${x} 2s linear 0.5s infinite`}}}]}})),st=p.forwardRef(function(e,a){const s=U({props:e,name:"MuiSkeleton"}),{animation:o="pulse",className:i,component:n="span",height:l,style:r,variant:f="text",width:g,...d}=s,u={...s,animation:o,component:n,variant:f,hasChildren:!!d.children},v=Q(u);return y.jsx(_,{as:n,ref:a,className:h(v.root,i),ownerState:u,...d,style:{width:g,height:l,...r}})});export{at as M,st as S};
