import{r}from"./index-pQZ3yIDG.js";const a=1e3,o=t=>new Promise(e=>setTimeout(e,t)),n=t=>r.lazy(async()=>(await o(a),t()));export{n as l};
